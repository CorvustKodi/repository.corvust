script.slurpee
=================

XBMC add-on to facilitate automatic downloading of your favourite regularly scheduled torrents.
