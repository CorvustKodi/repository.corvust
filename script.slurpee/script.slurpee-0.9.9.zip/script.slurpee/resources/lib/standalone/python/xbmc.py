LOGDEBUG=1
LOGINFO=2
LOGWARN=3
LOGERROR=4

def log(msg, level):
  print msg
